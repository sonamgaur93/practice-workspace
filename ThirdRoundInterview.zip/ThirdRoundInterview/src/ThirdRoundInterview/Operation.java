package ThirdRoundInterview;



public class Operation{  
	int data=50; //instance variable  

	void change(int data){  
		this.data=data+100;//changes will be in the local variable only  
	}  

	public static void main(String args[]){  
		Operation op=new Operation();  
		Integer i = 50;
		System.out.println("before change "+op.data);  
		op.change(i);  
		System.out.println("after change "+op.data);  
		System.out.println(i); 

	}  
}  