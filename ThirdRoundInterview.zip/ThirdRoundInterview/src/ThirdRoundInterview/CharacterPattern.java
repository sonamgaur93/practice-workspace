package ThirdRoundInterview;

public class CharacterPattern {
public static void main(String[] args) {
	for(int i=1;i<=5;i++) {
		for(int j=5;j>i;j--) {
			System.err.print(" ");
		}
		
		
		for(int j=1;j<=i;j++) {
			System.err.print(+j  );
			System.err.print(" ");
		}System.err.println();
	}
	
	
}
}
