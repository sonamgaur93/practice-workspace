package ThirdRoundInterview;

import java.util.Scanner;

interface Prototype {  
	  
    public Prototype getClone();  
     
}
class EmployeeRecord implements Prototype{  
     
  private int id;  
  private String name, designation;  
  private double salary;  
  private String address;  
     
  public EmployeeRecord(){  
           System.out.println("   Employee Records of Oracle Corporation ");  
           System.out.println("---------------------------------------------");  
           System.out.println("Eid"+"\t"+"Ename"+"\t"+"Edesignation"+"\t"+"Esalary"+"\t\t"+"Eaddress");  
     
}  
 
public  EmployeeRecord(int id, String name, String designation, double salary, String address) {  
         
       this();  
       this.id = id;  
       this.name = name;  
       this.designation = designation;  
       this.salary = salary;  
       this.address = address;  
   }  
     
 public void showRecord(){  
         
       System.out.println(id+"\t"+name+"\t"+designation+"\t"+salary+"\t"+address);  
  }  
 
   @Override  
   public Prototype getClone() {  
         
       return new EmployeeRecord(id,name,designation,salary,address);  
   }  
}

public class PrototypeDemo {

	public static void main(String[] args) {
		 System.out.print("Enter Employee Id: ");  
		Scanner s=new Scanner(System.in);
		int id=s.nextInt();
	 
		  
		    System.out.print("Enter Employee Name: "); 
		    Scanner s1=new Scanner(System.in);
		    String name=s1.nextLine();
		    
		    
		    System.out.print("Enter Employee Designation: "); 
		    Scanner s2=new Scanner(System.in);
		    String designation=s2.nextLine();
		
		    
		    System.out.print("Enter Employee Address: "); 
		    Scanner s3=new Scanner(System.in);
		    String address=s3.nextLine();
		    
		    
	        System.out.print("Enter Employee Salary: "); 
	        Scanner s4=new Scanner(System.in);
	        double salary=s4.nextDouble();
	        
	        EmployeeRecord e1=new EmployeeRecord(id,name,designation,salary,address); 
	        
	        e1.showRecord();  
	        EmployeeRecord e2=(EmployeeRecord) e1.getClone();  
	        e2.showRecord();
	}

}
