package ThirdRoundInterview;

public class FrequencyCalculation {

	public static void main(String[] args) {
		int []arr=new int[] {1,2,3,2,2,3,3,5,5,5,4};	
		int []arr1=new int[arr.length];
		int frcalculation=-1;
		int count=1;
		
		
	for(int i=0;i<arr.length;i++) {
	  for(int j=i+1;j<arr.length;j++) {
		  if(arr[i]==arr[j]) {
			  count++;
			  arr1[j]=frcalculation;
		  }
	  }
	  
	  if(arr1[i]!=frcalculation) {
		  arr1[i]=count;
		 
	  }
	  count=1;
	}
	
	System.out.println("frequency is:");
	for(int i =0;i<arr1.length;i++) {
		if(arr1[i]!=frcalculation) {
			System.out.println(+arr[i]+ " " +arr1[i]);	
		}
	}
	}

}
