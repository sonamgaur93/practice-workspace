package ThirdRoundInterview;

public class BinarySearch {
	static int index=-1;
	void binarySearcht(int array[],int beg,int end,int search) {
		int mid;
		if(end>=beg) {
			mid=(beg+end)/2;
			if(array[mid]==search) {
				index=mid;
			
			}else if(array[mid]<search){
				binarySearcht(array,mid+1,end,search);
			}else
				binarySearcht(array,beg,mid-1,search);
				
			}
	}

	public static void main(String[] args) {
		int []array=new int[] {23,24,56,77,89,90};
		int search=8;
		int beg=0;
		
		int end=array.length-1;
		BinarySearch b= new BinarySearch();
		b.binarySearcht(array,beg,end, search);
		if(index!=-1)
			System.err.println("no is present:"+index);
		else
			System.err.println("not present");

		
		}

	}


