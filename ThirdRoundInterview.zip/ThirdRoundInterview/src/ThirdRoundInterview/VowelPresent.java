package ThirdRoundInterview;

public class VowelPresent {

	public static void main(String[] args) {
		String s="my name is sonam";
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u') 
				System.out.println("Given string contains " + 
						s.charAt(i)+" at the index " + i);

		}


		//		check the number is prime

		//		int n=3;
		//		if(n%2==0) {
		//			System.out.println("no is not prime"+n);
		//		}else
		//			System.out.println("no is prime:"+n);

		//	no prime

		int n=10;
		int flag=0;
		int m=0;
		m=n/2;
		if(n==0||n==1) {

			System.out.println("no is not prime"+n);
		}else {
			for(int j=2;j<=m;j++) {
				if(n%j==0)
				{
					System.out.println("no is not prime"+n);
					flag=1;
					break;

				}

			}
			if(flag==0) {
				System.out.println("no is prime"+n);
			}
		}

	}


}
