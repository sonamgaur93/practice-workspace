package ThirdRoundInterview;



import java.lang.reflect.Array;

public class BinarySearchTesting {


	private static void binarySearch(int []arr,int beg,int end,int search) {
		int mid;
		if(end>=beg) {

			mid=(beg+end)/2;

			if(arr[mid]==search) {
				System.err.println("no is present:");

			}else if(arr[mid]<search) {

				binarySearch(arr,mid+1,end,search);

			}else if(arr[mid]>search)
			{
				binarySearch(arr,beg,mid-1,search);
			}
		}else
		{
			System.err.println("no is not present");
		}
	}
	public static void main(String[] args) {

		int arr[] =new int[] {23,45,67,89,90};
		int search=3;

		int beg=0;
		int end=arr.length-1;
		binarySearch(arr,beg,end,search);
	}
}
