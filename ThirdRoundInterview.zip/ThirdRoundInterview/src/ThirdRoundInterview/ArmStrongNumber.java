package ThirdRoundInterview;

public class ArmStrongNumber {
	public static void main(String [] args) {
	int  n=153;
	int result=0;
	while(n/10!=0)
	{
	int digit=n%10;
	result=result+(digit*digit*digit);
     n=n/10;

	}
	if(result==n) {
		System.out.println("no is armstrong"+result);
	}else
		System.out.println("no is not armstrong"+result);
	}
}
