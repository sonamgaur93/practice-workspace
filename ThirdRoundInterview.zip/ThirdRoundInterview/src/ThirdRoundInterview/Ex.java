package ThirdRoundInterview;

public class Ex {
public static void main(String[] args) {
	int fact =1;
	int n=5;
	for(int i=1;i<=5;i++)
	{
		fact=fact*i;
	}System.err.println(fact);
	
	
	
}
}
