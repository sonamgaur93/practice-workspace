package ThirdRoundInterview;

public class LinearSearch {
	
	
	public static void main(String[] args) {
		int []array=new int[] {23,14,15,78,90,23};
		int search=78;
		int index=0;
		
		for(int i=0;i<array.length;i++) {
			if(array[i]==search) {
				index=i;
				break;
			}
		}
		if(index!=0)
			System.err.println(index);
		else
			System.err.println("not present");

}
}
