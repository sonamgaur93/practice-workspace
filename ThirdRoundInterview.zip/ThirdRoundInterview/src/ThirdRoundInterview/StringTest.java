package ThirdRoundInterview;

import java.util.HashMap;
import java.util.Map;

public class StringTest {
	public static void main(String[] args) {
//find out size of each character in this program	
		
		String s="my name is sonam";
		
		char[] ch=s.toCharArray();
	   Map<Character, Integer> map=new HashMap<>();
	   
	   
	for(int i=0;i<ch.length;i++) {
		if(map.containsKey(ch[i])) {
			map.put(ch[i],map.get(ch[i])+1);
			
		}else
			map.put(ch[i], 1);
	}System.out.println(map);
		
	
	}

}
