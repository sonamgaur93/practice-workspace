package ThirdRoundInterview;

interface Cast{
	void add();
}



public class Interview {
	public static void main(String[] args) {
		
	}

}
