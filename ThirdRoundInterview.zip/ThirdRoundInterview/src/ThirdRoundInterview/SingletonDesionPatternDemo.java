package ThirdRoundInterview;

import java.io.Serializable;

//Egar initilization
class Singleton implements Serializable, Cloneable{

	static Singleton singleton = null;	
	private Singleton() {

	}
	
	public synchronized static Singleton getInstance() {
		if(singleton == null)
			singleton = new Singleton();
		return singleton;
	}
	
	 protected Object readResolve() {  
         return getInstance();  
     }  
	 
	 @Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return getInstance();
	}

}


public class SingletonDesionPatternDemo {

	public static void main(String[] args) throws CloneNotSupportedException {
		
		Singleton singleton1 = Singleton.getInstance();
		Singleton singleton3 = Singleton.getInstance();
		Singleton singleton2 = 	(Singleton) singleton1.clone();	
		System.err.println(singleton1);
		System.err.println(singleton2);
		System.err.println(singleton3);

	}

}
