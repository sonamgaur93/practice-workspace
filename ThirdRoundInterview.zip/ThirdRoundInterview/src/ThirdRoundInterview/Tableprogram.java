package ThirdRoundInterview;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class Tableprogram {
	
	public static void main(String[] args) {
		int number = new Scanner(System.in).nextInt();
		
		
		for(int i=1;i<=10; i++) {
			int resul = number*i;
			System.err.println(resul);
		}
		
		
		List<Integer> list = Arrays.asList(1,3,4,5,6,7);
		Iterator<Integer> iterator = list.iterator();
		while(iterator.hasNext()){
			System.err.println("");
		}
	}

}
