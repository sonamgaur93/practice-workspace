package ThirdRoundInterview;

public class ArrayTest {

	public static void main(String[] args) {
		int []arr=new int[] {10,8,6,18,4};
		int min=arr[2];
		int max=arr[2];
		for(int i=0;i<5;i++) {
			if(arr[i]%2==0 && min>arr[i]) {
				min=arr[i];
			}
		}
		System.err.println("min even no:" +min);
		
		
		for(int i=0;i<5;i++) {
			if(arr[i]%2==0 && max<arr[i]) {
				max=arr[i];
			}
		}
		System.err.println("max even no:" +max);
	}
}

