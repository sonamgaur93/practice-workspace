package ThirdRoundInterview;
import java.util.Scanner;

public class SelectionSort {
	public static void main(String[] args) {
        int[]arr = new int[] {12,34,45,56,67,56};

		//bubblesort
		for (int i = 0; i < arr.length; i++)   
		{  
			for (int j = i + 1; j < arr.length; j++){  
				int tmp = 0;  
				if (arr[i] > arr[j])   
				{  
					tmp = arr[i];  
					arr[i] = arr[j];  
					arr[j] = tmp;  
				}  
			}  
		}
		for(int ar :arr) {
			System.err.print(ar + " ");
		}	
	}
}


