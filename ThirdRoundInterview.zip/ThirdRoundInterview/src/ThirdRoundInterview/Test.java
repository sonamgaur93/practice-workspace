package ThirdRoundInterview;

public class Test {
	
	void swap(int c,int d) {
		
		c=c+d;
		d=c-d;
		c=c-d;
		System.err.print("c is:"+c+ " d is:"+d);
	}
	
	
	
	public static void main(String[] args)
	{
		
		Test t=new Test();
		String s="12345";
		char[] c=s.toCharArray();
		for(int i=c.length-1;i>=0;i--) {
			
			System.err.println(c[i]);
		}
		
		
//		swap two numbers
		int a=20;
		int b=30;
		int d=0;
		d=a;
		a=b;
		b=d;
		System.err.print("a is:"+a+ " b is:"+b);
		
		t.swap(50,60);
		
		
		String s1="    sonam    ";
		
		System.err.println(s1.trim());
		
	}
}
