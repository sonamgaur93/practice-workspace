package ThirdRoundInterview;

public class ReversString {

	public static void main(String[] args) {

	String s="sonam";
	
	}

}
