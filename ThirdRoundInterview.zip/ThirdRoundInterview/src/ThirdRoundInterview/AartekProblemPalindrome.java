package ThirdRoundInterview;

import java.util.Scanner;

public class AartekProblemPalindrome {

	public static void main(String[] args) {
		Scanner kn =new Scanner(System.in);
		int n=kn.nextInt();
		int temp,rev=0;
		int palindrome=0;
		temp=n;
		int sum=0,result=0,sum1=0;

		while(n!=0) {
			int digit =n%10;
			rev=rev*10+digit;
			n=n/10;
		}

		System.err.println("no is reversed: "+rev);

		sum =temp+rev;
		System.err.println("sum is : "+sum);

		int sum2=sum;

		//		palindrome ki condition 

		while(sum!=0) {

			int digit =sum%10;
			sum1=sum1*10+digit;
			sum=sum/10;
		}
		System.err.println("reversed no: "+sum1);

		if(sum1==sum2) {
			result =sum1+sum2;
			System.err.println("sum is: "+result);
		}
	}

}
