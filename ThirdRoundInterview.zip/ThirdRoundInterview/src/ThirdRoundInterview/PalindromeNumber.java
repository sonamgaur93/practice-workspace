package ThirdRoundInterview;

public class PalindromeNumber {
	public static void main(String[] args) {
		int n=343;
		
		int temp,rev=0;
		temp=n;
		while(n!=0){
			int digit=n%10;
			rev=rev*10+digit;
			n=n/10;
		}
	    System.out.println("Reversed Number: " + rev);
	    if(temp==rev) {

	        System.out.println("no is palindrome "+rev );
	    }else

	        System.out.println("no is not palindrome "+temp) ;
		
	}

}
