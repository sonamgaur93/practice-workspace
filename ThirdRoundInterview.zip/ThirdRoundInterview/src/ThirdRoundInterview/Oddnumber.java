package ThirdRoundInterview;

public class Oddnumber {
	public static void main(String[] args) {
		
		for(int i=0;i<100;i++) {
			if(i%2==0)
			{
//				System.err.println("even no "+i);
			}else
			{
				System.err.println("odd no"+i);
			}
		}
	}

}
