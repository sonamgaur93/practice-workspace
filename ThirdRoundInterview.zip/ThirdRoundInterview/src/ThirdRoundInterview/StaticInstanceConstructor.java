package ThirdRoundInterview;



       
  public class StaticInstanceConstructor {  
		public static void main(String args[]){  
			String s=new String("sonam");
			String s1=s.concat("gour");
			System.out.println(s1);
		}
}