package ThirdRoundInterview;

public class Pattern {
	public static void main(String[] args) {
//		downward tringle star pattern		
		for(int i=0;i<5;i++)
		{
			for(int j=5;j>i;j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
//		pyramid star pattern
		for(int k=0;k<6;k++)
		{
			for(int j=6 ;j>k;j--) {
					System.out.print(" ");
			}
			for(int j=0;j<=k;j++) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
//	reverse pyramid star pattern
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
					System.out.print(" ");
			}
			for(int j=5;j>i;j--) {
				System.out.print("* ");
			}
			System.out.println();
		}
		
		
//		Right Pascal's Triangle
		
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("* ");
			}
			System.out.println();
			
		}
		for(int i=0;i<4;i++) {
			for(int j=4;j>i;j--) {
				System.out.print("* ");	
			}
			System.out.println();
		}
	
		
//		 Sandglass Star Pattern
		
			for(int l=0;l<5;l++) {
				for(int m=0;m<=l;m++) {
					System.out.print(" ");
				}
				for(int m=5;m>l;m--) {
					System.out.print("* ");	
				}
				System.out.println();	
			}
			for(int l=0;l<5;l++) {
				for(int m=4;m>l;m--) {
					System.out.print(" ");	
				}
				for(int m=0;m<=l+1;m++) {
					System.out.print("* ");	
				}
				System.out.println();	
	
	}

}
}