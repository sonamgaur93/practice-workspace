package ThirdRoundInterview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Programmer{
	String name;
	Integer id;
	Programmer(String name,int id){
		this.name=name;
		this.id=id;
	}
	
	@Override
	public String toString() {
		return "name=" + name + ", id=" + id ;
	}
	
}

public class ComparatorProgrammer {

	public static void main(String[] args) {
		Programmer p1=new Programmer(null,12);
		Programmer p2=new Programmer("gourav",22);

		List<Programmer> l=new ArrayList<>();
		l.add(p1);
		l.add(p2);

		Comparator<Programmer> idComparator= new Comparator<Programmer>(){

			@Override
			public int compare(Programmer c1, Programmer c2) {
				return c1 != null && c2 != null ? c1.id.compareTo(c2.id) : 0;
			}
		};
		Collections.sort(l, idComparator);
		
		
		
		System.err.println(l);
		
		
		
		Comparator<Programmer> nameComparator= new Comparator<Programmer>(){

			@Override
			public int compare(Programmer c1, Programmer c2) {
				return c1.name != null && c2.name != null ? c1.name.compareTo(c2.name) : 1;
			}
		};
		
		
Collections.sort(l, nameComparator);
		
		
		
		System.err.println(l);



	}

}
