package ThirdRoundInterview;

public class FibnosseTest {
	static int n1=0,n2=1,n3;
	static void printFibnosse(int count) {
		if(count>0) {
		n3=n1+n2;
		System.out.println(+n3);
		n1=n2;
		n2=n3;
		
		printFibnosse(count-1);
	}
	}
	//without recursion
	public static void main(String[] args) {
	
//		int	n1=0,n2=1,n3,count=10;
//		System.out.println(n1+  " " +n2);
//		for(int i=2;i<count;i++) {
//			n3=n1+n2;
//			System.out.println(+n3);
//			n1=n2;
//			n2=n3;
//		}
	//with recursion		
	int count=10;
	System.out.println(n1+" "+n2);
	printFibnosse(count-2);
}

}
