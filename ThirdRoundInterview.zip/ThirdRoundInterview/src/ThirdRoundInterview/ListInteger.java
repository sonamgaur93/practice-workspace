package ThirdRoundInterview;

import java.util.Scanner;

public class ListInteger {

	public static void main(String[] args) {
		Scanner kb=new Scanner(System.in);
		int i=kb.nextInt();
		recursionFunction(i);
		System.err.println(fact);
		
	}
	
	//Factorial of number pass from the keyboard
	static int fact=1;
	public static void recursionFunction(int i) {
		
		for(int j=1;j<=i;j++) {
			fact=fact*j;
		}
		
		
	}

}
