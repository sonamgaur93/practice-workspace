package ThirdRoundInterview;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapTest {
	public static void main(String[] args) {
		Map<Integer,String> map=new HashMap<>();
		map.put(1, "sonam");
		map.put(2, "ram");
		map.put(3, "gour");
		map.put(4, "gourav");
		
		System.out.println(map.keySet());
		System.out.println(map.values());
		for(Entry e:map.entrySet()) {
			System.out.println(e.getKey()+ " "+e.getValue());
		}
		
		System.out.println(map.containsKey(1));
		System.out.println(map.get(1));
	}

}
