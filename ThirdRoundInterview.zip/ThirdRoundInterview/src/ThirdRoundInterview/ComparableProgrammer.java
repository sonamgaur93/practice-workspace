package ThirdRoundInterview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Employee implements Comparable<Employee>{
	String name;
	int id;
	Employee(String name,int id){
		this.name=name;
		this.id=id;
	}
	public String toString(){
		return String.valueOf(this.id);
	}
	@Override
	public int compareTo(Employee e) {
		if(this.id>e.id) {
			return 1;
		}
		else if(this.id<e.id){
			return-1;
		}else {
			return 0;
		}
	}
	
}

public class ComparableProgrammer {

	public static void main(String[] args) {
		Employee e1=new Employee("sonam",12);
		Employee e2=new Employee("ashoknagar",10);
	List<Employee> list=new ArrayList<>();
	list.add(e1);
	list.add(e2);
	
	Collections.sort(list);
System.err.println(list);
	}

}
