package ConstructorTest;

public class Address {
 String city;
 String village;
 
 Address(String city,String village){
	 this.city=city;
	 this.village=village;
 }
	public String toString(){
		return city+ " "   +village ;
	}
	
}
