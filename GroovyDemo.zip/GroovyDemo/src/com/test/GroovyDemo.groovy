package com.test


println ('hello sonam')

def _name1 = "sonam"
_name1 = 10

println _name1
_Name1