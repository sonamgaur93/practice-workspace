package com.test

class Main {
	
static void main(args) {
	println("hello")
	println("hello")
		
	def list = [1,3, 4]
	
	ArrayList listt = new ArrayList();
	listt.add(2)
	
	for(int i : listt) {
		println(i)
	}
	
	
	for(i in listt){
           println(i)
                println(i)
      }
		
	if(10 in list){
	     println('aa')
	     println('aa')
	    }
	 println('janu')
	}
}