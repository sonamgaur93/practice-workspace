package AutowiredTest;

public class B {
	B(){

		System.out.println("b is create");
	}
	void print() {
		System.out.println("hello b");
	}

}
